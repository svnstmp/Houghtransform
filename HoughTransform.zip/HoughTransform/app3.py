import numpy as np
import matplotlib.pyplot as plt
from skimage.transform import hough_line, hough_line_peaks
from flask import Flask, render_template, request, jsonify
import io
from PIL import Image
import base64

# Global variables to store the last point and the image
lastx, lasty = None, None
input_image = np.zeros((200, 200), dtype=np.uint8)

# Function to draw a line between two points
def draw_line(x0, y0, x1, y1):
    # Ensure that we have valid numbers before attempting to draw
    if None in (x0, x1, y0, y1):
        return
    print("Drawing line from ({}, {}) to ({}, {})".format(x0, y0, x1, y1))  # Print the coordinates of the line
    x, y = np.linspace(x0, x1, 100), np.linspace(y0, y1, 100)
    for (xi, yi) in zip(x.astype(int), y.astype(int)):
        if 0 <= xi < input_image.shape[1] and 0 <= yi < input_image.shape[0]:
            input_image[yi, xi] = 255

# Mouse event handlers
def on_press(event):
    global lastx, lasty
    lastx, lasty = event.xdata, event.ydata

def on_release(event):
    global lastx, lasty
    draw_line(lastx, lasty, event.xdata, event.ydata)
    lastx, lasty = None, None
    ax_input_image.imshow(input_image, cmap='gray')  # Display the input image after drawing the line
    update()

def on_move(event):
    global lastx, lasty
    if event.button and event.xdata is not None and event.ydata is not None:
        draw_line(lastx, lasty, event.xdata, event.ydata)
        lastx, lasty = event.xdata, event.ydata
        ax_input_image.imshow(input_image, cmap='gray')  # Display the input image while drawing the line
        update()

# Update the image and Hough transform
def update():
    ax_input_image.imshow(input_image, cmap='gray')
    ax_input_image.set_title('Input Image')
    ax_hough_transform.cla()  # Clear the previous Hough transform
    perform_hough_transform(input_image)
    plt.draw()

# Perform Hough transform and plot
def perform_hough_transform(image):
    h, theta, d = hough_line(image)
    print("Number of detected lines:", len(theta))
    ax_hough_transform.imshow(np.log(1 + h),
                              extent=[np.rad2deg(theta[-1]), np.rad2deg(theta[0]), d[-1], d[0]],
                              cmap='gray', aspect='auto')
    ax_hough_transform.set_title('Hough Transform')
    ax_hough_transform.set_xlabel('Angles (degrees)')
    ax_hough_transform.set_ylabel('Distance (pixels)')

# Set up the figure and connect the event handlers
fig, (ax_input_image, ax_hough_transform) = plt.subplots(1, 2, figsize=(10, 5))
fig.canvas.mpl_connect('button_press_event', on_press)
fig.canvas.mpl_connect('button_release_event', on_release)
fig.canvas.mpl_connect('motion_notify_event', on_move)

update()  # Initial draw

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/hough-transform', methods=['POST'])
def hough_transform():
    image_data = request.get_json().get('image').split(',')[1]
    # Convert the base64 encoded image data to numpy array
    image = Image.open(io.BytesIO(base64.b64decode(image_data)))
    image_array = np.array(image)
    image_array = np.mean(image_array, axis=2)  # Convert to grayscale
    h, theta, d = hough_line(image_array)
    
    # Perform Hough transform and plot
    hough_image = np.log(1 + h)
    extent = [np.rad2deg(theta[-1]), np.rad2deg(theta[0]), d[-1], d[0]]
    
    # Encode the Hough image as base64
    buffered = io.BytesIO()
    plt.imsave(buffered, hough_image, cmap='gray', format='png')
    hough_image_base64 = base64.b64encode(buffered.getvalue()).decode('utf-8')
    
    return jsonify(houghImageUrl=f'data:image/png;base64,{hough_image_base64}')

if __name__ == '__main__':
    app.run(debug=True)
